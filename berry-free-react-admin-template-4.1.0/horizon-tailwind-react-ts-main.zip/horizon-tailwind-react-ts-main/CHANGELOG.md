# Changelog

## [2.0.0] 2025-13-01

### Upgraded to React 19 ⚡️

## [1.0.0] 2023-03-23

### Original Release

- Added Tailwind CSS as base framework
