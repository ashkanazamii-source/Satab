export const DASHBOARD_PATH = '/sample-page';

const config = {
  fontFamily: `'Roboto', sans-serif`,
  borderRadius: 8
};

export default config;
